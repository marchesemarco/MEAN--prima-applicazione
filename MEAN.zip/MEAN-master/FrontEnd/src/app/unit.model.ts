export class Unit
{
    constructor(public Unit: string, public Cost: string, public Hit_Speed: string, public Speed: string, public Deploy_Time: string, public Range: string, public Target: string, public Count: string, public Transport: string, public Type: string, public Rarity: string){};
}
